package be.vdab;
public class RekeningNummerException extends Exception {
    public RekeningNummerException() {
        
    }
}
